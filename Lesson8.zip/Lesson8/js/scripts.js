$(document).ready(function () {
    $('.mobile-menu').on('click', function () {
        $('.menu').slideToggle();
    })
})